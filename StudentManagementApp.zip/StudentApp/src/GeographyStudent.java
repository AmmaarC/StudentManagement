import java.util.List;

/**
 * A subclass representing a Geography student.
 */
class GeographyStudent extends Student {
    private static final int MODULE_COUNT = 8;

    /**
     * Constructor to initialise a Geography student.
     *
     * @param surname      The surname of the student.
     * @param firstName    The first name of the student.
     * @param moduleGrades The grades of the student's modules.
     * @param year         The year of the student.
     */
    public GeographyStudent(String surname, String firstName, List<Integer> moduleGrades, int year) {
        super("Geography", surname, firstName, moduleGrades, year);
    }

    @Override
    public int calculateFinalResult() {
        int sum = calculateModuleGradesSum();
        return (int) Math.ceil((double) sum / MODULE_COUNT);
    }

    /**
     * Calculate the sum of module grades.
     *
     * @return The sum of module grades.
     */
    private int calculateModuleGradesSum() {
        return getModuleGrades().stream().mapToInt(Integer::intValue).sum();
    }
}