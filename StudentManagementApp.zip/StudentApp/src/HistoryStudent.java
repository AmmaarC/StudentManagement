import java.util.List;

/**
 * A subclass representing a History student.
 */
class HistoryStudent extends Student {
    private static final int MODULE_COUNT = 10;

    /**
     * Constructor to initialise a History student.
     *
     * @param surname      The surname of the student.
     * @param firstName    The first name of the student.
     * @param moduleGrades The grades of the student's modules.
     * @param year         The year of the student.
     */
    public HistoryStudent(String surname, String firstName, List<Integer> moduleGrades, int year) {
        super("History", surname, firstName, moduleGrades, year);
    }

   
	@Override
    public int calculateFinalResult() {
        int sum = calculateModuleGradesSum();
        return (int) Math.ceil((double) sum / MODULE_COUNT);
    }

    /**
     * Calculate the sum of module grades.
     *
     * @return The sum of module grades.
     */
    private int calculateModuleGradesSum() {
        return getModuleGrades().stream().mapToInt(Integer::intValue).sum();
    }
}