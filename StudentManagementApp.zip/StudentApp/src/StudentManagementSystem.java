import java.util.List;
import java.util.Scanner;

/**
 * A class to demonstrate the student management system.
 */
public class StudentManagementSystem {
    private final StudentManager studentManager;

    /**
     * Constructor to initialise the StudentManagementSystem.
     *
     * @param students The list of students.
     */
    public StudentManagementSystem(List<Student> students) {
        this.studentManager = new StudentManager(students);
    }

    /**
     * Display the menu options.
     */
    private void displayMenu() {
        System.out.println("Menu:");
        System.out.println("1. Print results for one year and one subject");
        System.out.println("2. Print results by year and subject");
        System.out.println("3. Print results alphabetically by surname");
        System.out.println("4. Print results in descending order");
        System.out.println("5. Print grades");
        System.out.println("6. Print students who failed an individual module");
        System.out.println("7. Exit");
        System.out.print("Enter your choice: ");
    }

    /**
     * Execute the selected menu option.
     *
     * @param choice The user's choice.
     */
    private void executeMenuOption(int choice) {
        try {
            switch (choice) {
                case 1:
                    studentManager.printResultsForSubjectAndYear();
                    break;
                case 2:
                    studentManager.printResultsByYearAndSubject();
                    break;
                case 3:
                    studentManager.printResultsAlphabetically();
                    break;
                case 4:
                    studentManager.printResultsDescendingOrder();
                    break;
                case 5:
                    studentManager.printResultsWithGrades();
                    break;
                case 6:
                    studentManager.findFailedStudentsByModule();
                    break;
                case 7:
                    System.out.println("Exiting the program.");
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a number between 1 and 7.");
            }
        } catch (Exception e) {
            System.err.println("An error occurred: " + e.getMessage());
        }
    }

    /**
     * Run the student management system.
     */
    public void run() {
        try {
            Scanner scanner = new Scanner(System.in);
            int choice;

            do {
                displayMenu();
                choice = scanner.nextInt();
                scanner.nextLine();

                executeMenuOption(choice);

            } while (choice != 7);

        } catch (Exception e) {
            System.err.println("An error occurred: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        try {
            // Read student records from a file
            List<Student> students = FileManager.readStudentRecords("C:\\Users\\gg\\Downloads\\Data_File_For_Assignment.csv");

            // Create a StudentManagementSystem and run it
            new StudentManagementSystem(students).run();

        } catch (Exception e) {
            System.err.println("An error occurred: " + e.getMessage());
        }
    }
}