import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * A class to manage file operations for student records.
 */
class FileManager {
    /**
     * Read student records from a file.
     *
     * @param filePath The path of the file.
     * @return A list of students.
     * @throws IOException If an I/O error occurs.
     */
    public static List<Student> readStudentRecords(String filePath) throws IOException {
        List<Student> students = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                int year = Integer.parseInt(parts[0]);
                String subject = parts[1];
                String surname = parts[2];
                String firstName = parts[3];
                List<Integer> moduleGrades = extractModuleGrades(parts);

                students.add(createStudent(subject, surname, firstName, moduleGrades, year));
            }
        }

        return students;
    }

    /**
     * Extract module grades from the parts array.
     *
     * @param parts The parts array.
     * @return List of module grades.
     */
    static List<Integer> extractModuleGrades(String[] parts) {
        return Arrays.stream(parts)
                .skip(4)
                .map(Integer::parseInt)
                .collect(Collectors.toList());
    }

    /**
     * Create a student based on the subject.
     *
     * @param subject      The subject of the student.
     * @param surname      The surname of the student.
     * @param firstName    The first name of the student.
     * @param moduleGrades The grades of the student's modules.
     * @param year         The year of the student.
     * @return A new Student instance.
     */
    private static Student createStudent(String subject, String surname, String firstName, List<Integer> moduleGrades, int year) {
        switch (subject) {
            case "History":
                return new HistoryStudent(surname, firstName, moduleGrades, year);
            case "Geography":
                return new GeographyStudent(surname, firstName, moduleGrades, year);
            case "Maths":
                return new MathsStudent(surname, firstName, moduleGrades, year);
            default:
                throw new IllegalArgumentException("Invalid subject: " + subject);
        }
    }
}