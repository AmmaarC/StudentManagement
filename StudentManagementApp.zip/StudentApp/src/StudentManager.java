import java.util.*;
import java.util.stream.Collectors;

class StudentManager {
    private final List<Student> students;
    private final Scanner scanner;

    public StudentManager(List<Student> students) {
        this.students = students;
        this.scanner = new Scanner(System.in);
    }

    private String askForSubject() {
        System.out.println("Enter the subject (History, Geography, or Maths):");
        return scanner.nextLine().trim();
    }

    private int askForYear() {
        System.out.println("Enter the year:");
        return Integer.parseInt(scanner.nextLine().trim());
    }

    private void printStudentInfo(Student student, String message) {
        System.out.println("    " + student.getFirstName() + " " + student.getSurname() + " - " + message);
    }

    private void printStudentResults(List<Student> students, String message) {
        System.out.println(message);
        for (Student student : students) {
            printStudentInfo(student, message + ": " + student.calculateFinalResult());
        }
    }

    public void printResultsForSubjectAndYear() {
        String subject = askForSubject();
        int year = askForYear();

        List<Student> selectedStudents = students.stream()
                .filter(student -> student.getSubject().equalsIgnoreCase(subject) && student.getYear() == year)
                .collect(Collectors.toList());

        printStudentResults(selectedStudents, "Student results for " + subject + " in year " + year);
    }

    public void printResultsByYearAndSubject() {
        Map<String, Map<String, List<Student>>> groupedByYear = students.stream()
                .collect(Collectors.groupingBy(s -> String.valueOf(s.getYear()),
                        Collectors.groupingBy(Student::getSubject)));

        for (Map.Entry<String, Map<String, List<Student>>> yearEntry : groupedByYear.entrySet()) {
            String year = yearEntry.getKey();
            System.out.println("Year: " + year);

            Map<String, List<Student>> subjectsInYear = yearEntry.getValue();

            for (Map.Entry<String, List<Student>> subjectEntry : subjectsInYear.entrySet()) {
                String subject = subjectEntry.getKey();
                System.out.println("  Subject: " + subject);

                List<Student> studentsInSubject = subjectEntry.getValue();
                studentsInSubject.forEach(student -> printStudentInfo(student, " Final Result: " + student.calculateFinalResult()));
            }
        }
    }

    public void printResultsAlphabetically() {
        Map<String, Map<String, List<Student>>> groupedByYearAndSubject = students.stream()
                .collect(Collectors.groupingBy(s -> String.valueOf(s.getYear()),
                        Collectors.groupingBy(Student::getSubject)));

        for (Map.Entry<String, Map<String, List<Student>>> yearEntry : groupedByYearAndSubject.entrySet()) {
            String year = yearEntry.getKey();
            System.out.println("Year: " + year);

            Map<String, List<Student>> subjectsInYear = yearEntry.getValue();

            for (Map.Entry<String, List<Student>> subjectEntry : subjectsInYear.entrySet()) {
                String subject = subjectEntry.getKey();
                System.out.println("  Subject: " + subject);

                List<Student> studentsInSubject = subjectEntry.getValue();
                List<Student> sortedStudents = studentsInSubject.stream()
                        .sorted(Comparator.comparing(Student::getSurname))
                        .collect(Collectors.toList());

                printStudentResults(sortedStudents, "Final Result");
            }
        }
    }

    public void printResultsDescendingOrder() {
        Map<String, Map<String, List<Student>>> groupedByYearAndSubject = students.stream()
                .collect(Collectors.groupingBy(s -> String.valueOf(s.getYear()),
                        Collectors.groupingBy(Student::getSubject)));

        for (Map.Entry<String, Map<String, List<Student>>> yearEntry : groupedByYearAndSubject.entrySet()) {
            String year = yearEntry.getKey();
            System.out.println("Year: " + year);

            Map<String, List<Student>> subjectsInYear = yearEntry.getValue();

            for (Map.Entry<String, List<Student>> subjectEntry : subjectsInYear.entrySet()) {
                String subject = subjectEntry.getKey();
                System.out.println("  Subject: " + subject);

                List<Student> studentsInSubject = subjectEntry.getValue();
                List<Student> sortedStudents = studentsInSubject.stream()
                        .sorted(Comparator.comparingInt(Student::calculateFinalResult).reversed())
                        .collect(Collectors.toList());

                printStudentResults(sortedStudents, "Final Result");
            }
        }
    }

    public void printResultsWithGrades() {
        Map<String, Map<String, List<Student>>> groupedByYearAndSubject = students.stream()
                .collect(Collectors.groupingBy(s -> String.valueOf(s.getYear()),
                        Collectors.groupingBy(Student::getSubject)));

        for (Map.Entry<String, Map<String, List<Student>>> yearEntry : groupedByYearAndSubject.entrySet()) {
            String year = yearEntry.getKey();
            System.out.println("Year: " + year);

            Map<String, List<Student>> subjectsInYear = yearEntry.getValue();

            for (Map.Entry<String, List<Student>> subjectEntry : subjectsInYear.entrySet()) {
                String subject = subjectEntry.getKey();
                System.out.println("  Subject: " + subject);

                List<Student> studentsInSubject = subjectEntry.getValue();

                for (Student student : studentsInSubject) {
                    int finalResult = student.calculateFinalResult();
                    String grade = calculateGrade(finalResult);
                    printStudentInfo(student, "Final Result: " + finalResult + " - Grade: " + grade);
                }
            }
        }
    }

    private String calculateGrade(int finalResult) {
        if (finalResult < 40) {
            return "Fail";
        } else if (finalResult >= 40 && finalResult <= 59) {
            return "Pass";
        } else if (finalResult >= 60 && finalResult <= 69) {
            return "Merit";
        } else {
            return "Distinction";
        }
    }

    public void findFailedStudentsByModule() {
        Map<String, Map<String, List<Student>>> groupedByYearAndSubject = students.stream()
                .collect(Collectors.groupingBy(s -> String.valueOf(s.getYear()),
                        Collectors.groupingBy(Student::getSubject)));

        for (Map.Entry<String, Map<String, List<Student>>> yearEntry : groupedByYearAndSubject.entrySet()) {
            String year = yearEntry.getKey();
            Map<String, List<Student>> subjectsInYear = yearEntry.getValue();

            boolean hasFailedStudents = subjectsInYear.values().stream()
                    .anyMatch(studentsInSubject -> studentsInSubject.stream()
                            .anyMatch(student -> student.getModuleGrades().stream().anyMatch(grade -> grade < 40)));

            if (hasFailedStudents) {
                System.out.println("Year: " + year);

                for (Map.Entry<String, List<Student>> subjectEntry : subjectsInYear.entrySet()) {
                    String subject = subjectEntry.getKey();
                    List<Student> studentsInSubject = subjectEntry.getValue();

                    List<Student> failedStudents = studentsInSubject.stream()
                            .filter(student -> student.getModuleGrades().stream().anyMatch(grade -> grade < 40))
                            .collect(Collectors.toList());

                    if (!failedStudents.isEmpty()) {
                        System.out.println("  Subject: " + subject);

                        for (Student student : failedStudents) {
                            long failedModulesCount = student.getModuleGrades().stream().filter(grade -> grade < 40).count();
                            printStudentInfo(student, "Marks: " + student.getModuleGrades() +
                                    " - Failed in " + failedModulesCount + " Module(s) for " + subject);
                        }
                    }
                }
            }
        }
    }
}