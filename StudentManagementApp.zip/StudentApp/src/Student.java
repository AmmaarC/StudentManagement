import java.util.List;

/**
 * A class representing a student with their results.
 */
abstract class Student {
    private final String subject;
    private final String surname;
    private final String firstName;
    private final List<Integer> moduleGrades;

    private final int year;

    /**
     * Constructor to initialise a student.
     *
     * @param subject      The subject of the student.
     * @param surname      The surname of the student.
     * @param firstName    The first name of the student.
     * @param moduleGrades The grades of the student's modules.
     * @param year         The year of the student.
     */
    public Student(String subject, String surname, String firstName, List<Integer> moduleGrades, int year) {
        this.subject = subject;
        this.surname = surname;
        this.firstName = firstName;
        this.moduleGrades = moduleGrades;
        this.year = year;
    }

    /**
     * Calculate and return the final result for the student.
     *
     * @return The final result.
     */
    public abstract int calculateFinalResult();

    /**
     * Get the full name of the student.
     *
     * @return The full name.
     */
    public String getSurname() {
        return surname;
    }

    /**
     * Get the full name of the student.
     *
     * @return The full name.
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * Get the subject of the student.
     *
     * @return The subject.
     */
    public String getSubject() {
        return subject;
    }

    /**
     * Get the year of the student.
     *
     * @return The year.
     */
    public int getYear() {
        return year;
    }

    /**
     * Get the module grades of the student.
     *
     * @return The module grades.
     */
    public List<Integer> getModuleGrades() {
        return moduleGrades;
    }
}